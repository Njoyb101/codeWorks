const express = require("express");
const path = require("path");
const app = express();
const port = 3000;

const  home = require("./routes/home.js");
const  users = require("./routes/users.js");

app.use(express.urlencoded({
    extended : true //retaining js object property
}));
app.use(express.json());

app.use(express.static(path.join(__dirname,"public")));// read access to public so  /public is default


app.use(home);
app.use(users);

app.listen(port);
