import qrcode
import qrcode.image.svg

myUrl = "https://github.com/Njoy95/codeWorks"


# Simple factory, just a set of rects.
factory = qrcode.image.svg.SvgImage
img = qrcode.make(myUrl, image_factory=factory)
img.save("method is basic.SVG")

# Fragment factory (also just a set of rects)
factory = qrcode.image.svg.SvgFragmentImage
img = qrcode.make(myUrl, image_factory=factory)
img.save("method is fragment.SVG")

# Combined path factory, fixes white space that may occur when zooming
factory = qrcode.image.svg.SvgPathImage
img = qrcode.make(myUrl, image_factory=factory)
img.save("method is combined.SVG")
