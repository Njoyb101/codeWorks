const express = require("express");


const router = express.Router();

const userList = require('./admin');


router.get("/",(req,res,next)=>{
    res.render("users",{
        pageTitle : "Home",
        path : "/home",
        userList : userList.users
    })
});


exports.routes= router;


