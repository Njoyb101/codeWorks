const express = require("express");


const router = express.Router();
const users = [];

router.get("/add-user",(req,res,next)=>{
    res.render("admin",{
        pageTitle : "Add User",
        path : "/add-user"
    })
});

router.post("/add-user",(req,res,next)=>{
    users.push({title : req.body.userName});
    console.log(users);
    res.redirect("/");
})


exports.routes= router;
exports.users= users;

