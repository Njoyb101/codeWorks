const express = require("express");
const path = require("path");



const app =express();
const port = 3000;

app.set('view engine','ejs');
app.set('views','views');

const adminRoute = require("./routes/admin");
const users = require("./routes/users");



// Above express 4.16.0 use this  ==>
//--------------------------------
app.use(express.urlencoded({
    extended : true
}));
app.use(express.json());

// Static read access
app.use(express.static(path.join(__dirname,"public"))); 

app.use('/admin',adminRoute.routes);
app.use(users.routes);

app.use((req, res, next) => {
    res.status(404).render("404",{ // render is looking in  'views/ejsMainViews' folder for file  404.ejs file
        pageTitle : "404",
        path : null
    })
});

app.listen(port);
